import 'package:flutter/material.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe18widget/GeneratedFrame18Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe7widget/GeneratedFrame7Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe6widget/GeneratedFrame6Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe19widget/GeneratedFrame19Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe20widget/GeneratedFrame20Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe21widget/GeneratedFrame21Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe22widget/GeneratedFrame22Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe23widget/GeneratedFrame23Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe24widget/GeneratedFrame24Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe25widget/GeneratedFrame25Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe26widget/GeneratedFrame26Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe27widget/GeneratedFrame27Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe28widget/GeneratedFrame28Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe29widget/GeneratedFrame29Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe30widget/GeneratedFrame30Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedmallmaptakemetherewidget/GeneratedMALLMAPtakemethereWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedmallmaptakemetherewidget1/GeneratedMALLMAPtakemethereWidget1.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedmallmaptakemetherewidget2/GeneratedMALLMAPtakemethereWidget2.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedmallmaptakemetherewidget3/GeneratedMALLMAPtakemethereWidget3.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedmallmaptakemetheredangerwidget/GeneratedMALLMAPtakemethereDANGERWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedmallmapresultswidget/GeneratedMALLMAPresultsWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedmallmapresultsdangerwidget/GeneratedMALLMAPresultsDANGERWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedsafetabwidget/GeneratedSafeTabWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedsafetabwidget1/GeneratedSafeTabWidget1.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generateddangertabwidget/GeneratedDangerTabWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generateddangertabwidget1/GeneratedDangerTabWidget1.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generateddangertabwidget2/GeneratedDangerTabWidget2.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generateddangertabwidget3/GeneratedDangerTabWidget3.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedsafetabwidget2/GeneratedSafeTabWidget2.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedsafetabwidget3/GeneratedSafeTabWidget3.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomeloadingwidget/GeneratedHomeLoadingWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomesearchedwidget/GeneratedHomeSearchedWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomesearchedwidget1/GeneratedHomeSearchedWidget1.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomesearcheddangerwidget/GeneratedHomeSearchedDangerWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomesearcheddangerwidget1/GeneratedHomeSearchedDangerWidget1.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomesearcheddangerwidget2/GeneratedHomeSearchedDangerWidget2.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomeloadingwidget1/GeneratedHomeLoadingWidget1.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomeloadingwidget2/GeneratedHomeLoadingWidget2.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomesearcheddangerwidget3/GeneratedHomeSearchedDangerWidget3.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomesearcheddangerwidget4/GeneratedHomeSearchedDangerWidget4.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomesearcheddangerwidget5/GeneratedHomeSearchedDangerWidget5.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomesearchiconpresseddangerwidget/GeneratedHomeSearchIconPressedDangerWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomeloadingwidget3/GeneratedHomeLoadingWidget3.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe16widget/GeneratedFrame16Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhometabwidget/GeneratedHOMETABWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generateddangermapresultswidget/GeneratedDANGERMAPRESULTSWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedsafemapresultswidget/GeneratedSAFEMAPRESULTSWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedframe31widget/GeneratedFrame31Widget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedsendwidget60/GeneratedSendWidget60.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedwelcomepagewidget/GeneratedWelcomePageWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedwelcomepagewidget1/GeneratedWelcomePageWidget1.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedqrscanwidget/GeneratedQRSCANWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedqrscandonewidget/GeneratedQRSCANDoneWidget.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedhomewidget42/GeneratedHomeWidget42.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedqrscanwidget1/GeneratedQRSCANWidget1.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedqrscandonewidget1/GeneratedQRSCANDoneWidget1.dart';
import 'package:flutterapp/mallwhere_20__20potato_20codersapp/generatedantdesigncopyrightcirclefilledwidget1/GeneratedAntdesigncopyrightcirclefilledWidget1.dart';

void main() {
  runApp(Mallwhere_20__20Potato_20CodersApp());
}

class Mallwhere_20__20Potato_20CodersApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedWelcomePageWidget',
      routes: {
        '/GeneratedFrame18Widget': (context) => GeneratedFrame18Widget(),
        '/GeneratedFrame7Widget': (context) => GeneratedFrame7Widget(),
        '/GeneratedFrame6Widget': (context) => GeneratedFrame6Widget(),
        '/GeneratedFrame19Widget': (context) => GeneratedFrame19Widget(),
        '/GeneratedFrame20Widget': (context) => GeneratedFrame20Widget(),
        '/GeneratedFrame21Widget': (context) => GeneratedFrame21Widget(),
        '/GeneratedFrame22Widget': (context) => GeneratedFrame22Widget(),
        '/GeneratedFrame23Widget': (context) => GeneratedFrame23Widget(),
        '/GeneratedFrame24Widget': (context) => GeneratedFrame24Widget(),
        '/GeneratedFrame25Widget': (context) => GeneratedFrame25Widget(),
        '/GeneratedFrame26Widget': (context) => GeneratedFrame26Widget(),
        '/GeneratedFrame27Widget': (context) => GeneratedFrame27Widget(),
        '/GeneratedFrame28Widget': (context) => GeneratedFrame28Widget(),
        '/GeneratedFrame29Widget': (context) => GeneratedFrame29Widget(),
        '/GeneratedFrame30Widget': (context) => GeneratedFrame30Widget(),
        '/GeneratedMALLMAPtakemethereWidget': (context) =>
            GeneratedMALLMAPtakemethereWidget(),
        '/GeneratedMALLMAPtakemethereWidget1': (context) =>
            GeneratedMALLMAPtakemethereWidget1(),
        '/GeneratedMALLMAPtakemethereWidget2': (context) =>
            GeneratedMALLMAPtakemethereWidget2(),
        '/GeneratedMALLMAPtakemethereWidget3': (context) =>
            GeneratedMALLMAPtakemethereWidget3(),
        '/GeneratedMALLMAPtakemethereDANGERWidget': (context) =>
            GeneratedMALLMAPtakemethereDANGERWidget(),
        '/GeneratedMALLMAPresultsWidget': (context) =>
            GeneratedMALLMAPresultsWidget(),
        '/GeneratedMALLMAPresultsDANGERWidget': (context) =>
            GeneratedMALLMAPresultsDANGERWidget(),
        '/GeneratedSafeTabWidget': (context) => GeneratedSafeTabWidget(),
        '/GeneratedSafeTabWidget1': (context) => GeneratedSafeTabWidget1(),
        '/GeneratedDangerTabWidget': (context) => GeneratedDangerTabWidget(),
        '/GeneratedDangerTabWidget1': (context) => GeneratedDangerTabWidget1(),
        '/GeneratedDangerTabWidget2': (context) => GeneratedDangerTabWidget2(),
        '/GeneratedDangerTabWidget3': (context) => GeneratedDangerTabWidget3(),
        '/GeneratedSafeTabWidget2': (context) => GeneratedSafeTabWidget2(),
        '/GeneratedSafeTabWidget3': (context) => GeneratedSafeTabWidget3(),
        '/GeneratedHomeLoadingWidget': (context) =>
            GeneratedHomeLoadingWidget(),
        '/GeneratedHomeSearchedWidget': (context) =>
            GeneratedHomeSearchedWidget(),
        '/GeneratedHomeSearchedWidget1': (context) =>
            GeneratedHomeSearchedWidget1(),
        '/GeneratedHomeSearchedDangerWidget': (context) =>
            GeneratedHomeSearchedDangerWidget(),
        '/GeneratedHomeSearchedDangerWidget1': (context) =>
            GeneratedHomeSearchedDangerWidget1(),
        '/GeneratedHomeSearchedDangerWidget2': (context) =>
            GeneratedHomeSearchedDangerWidget2(),
        '/GeneratedHomeLoadingWidget1': (context) =>
            GeneratedHomeLoadingWidget1(),
        '/GeneratedHomeLoadingWidget2': (context) =>
            GeneratedHomeLoadingWidget2(),
        '/GeneratedHomeSearchedDangerWidget3': (context) =>
            GeneratedHomeSearchedDangerWidget3(),
        '/GeneratedHomeSearchedDangerWidget4': (context) =>
            GeneratedHomeSearchedDangerWidget4(),
        '/GeneratedHomeSearchedDangerWidget5': (context) =>
            GeneratedHomeSearchedDangerWidget5(),
        '/GeneratedHomeSearchIconPressedDangerWidget': (context) =>
            GeneratedHomeSearchIconPressedDangerWidget(),
        '/GeneratedHomeLoadingWidget3': (context) =>
            GeneratedHomeLoadingWidget3(),
        '/GeneratedFrame16Widget': (context) => GeneratedFrame16Widget(),
        '/GeneratedHOMETABWidget': (context) => GeneratedHOMETABWidget(),
        '/GeneratedDANGERMAPRESULTSWidget': (context) =>
            GeneratedDANGERMAPRESULTSWidget(),
        '/GeneratedSAFEMAPRESULTSWidget': (context) =>
            GeneratedSAFEMAPRESULTSWidget(),
        '/GeneratedFrame31Widget': (context) => GeneratedFrame31Widget(),
        '/GeneratedSendWidget60': (context) => GeneratedSendWidget60(),
        '/GeneratedWelcomePageWidget': (context) =>
            GeneratedWelcomePageWidget(),
        '/GeneratedWelcomePageWidget1': (context) =>
            GeneratedWelcomePageWidget1(),
        '/GeneratedQRSCANWidget': (context) => GeneratedQRSCANWidget(),
        '/GeneratedQRSCANDoneWidget': (context) => GeneratedQRSCANDoneWidget(),
        '/GeneratedHomeWidget42': (context) => GeneratedHomeWidget42(),
        '/GeneratedQRSCANWidget1': (context) => GeneratedQRSCANWidget1(),
        '/GeneratedQRSCANDoneWidget1': (context) =>
            GeneratedQRSCANDoneWidget1(),
        '/GeneratedAntdesigncopyrightcirclefilledWidget1': (context) =>
            GeneratedAntdesigncopyrightcirclefilledWidget1(),
      },
    );
  }
}
